the folders contain{
	extras: content that I should delete but instead I put it here
	obj: you can't compile without it
}

file description{
	main.c: the main file
	err.h: error handler and request cartridge
	Music.wav: the sound
	Texture.png: the texture
 	Rdef: rom definition
	Readme.txt: readme
	Make.bat: auto compile, assemble and pack the rom (open it from cmd)
	OpenCmd.bat: open cmd
}

